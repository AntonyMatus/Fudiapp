<?php $__env->startSection('title'); ?> App Users <?php $__env->stopSection(); ?>

<?php $__env->startSection('icon'); ?> mdi-home <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section class="pull-up">
<div class="container">
<div class="row ">
<div class="col-md-12">
<div class="card py-3 m-b-30">

<div class="card-body">
<table class="table table-hover ">
<thead>
<tr>
<th>Usuario</th>
<th>Email</th>
<th>Telefono</th>
<th>Fecha de registro</th>
<th>Pedidos</th>
<th>Estado</th>
<th>Eliminar</th>
</tr>

</thead>
<tbody>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td width="15%"><?php echo e($row->name); ?></td>
<td width="20%"><?php echo e($row->email); ?></td>
<td width="10%"><?php echo e($row->phone); ?></td>
<td width="15%"><?php echo e(date('d-M-Y',strtotime($row->created_at))); ?></td>
<td width="10%"><?php echo e($row->countOrder($row->id)); ?></td>
<td width="10%">
    <?php if($row->status == 0): ?>
    <button type="button" class="btn btn-sm m-b-15 ml-2 mr-2 btn-success" onclick="confirmAlert('<?php echo e(Asset($link.'status/'.$row->id)); ?>')">Activo</button>
    <?php else: ?>
    <button type="button" class="btn btn-sm m-b-15 ml-2 mr-2 btn-danger" onclick="confirmAlert('<?php echo e(Asset($link.'status/'.$row->id)); ?>')">Bloqueado</button>
    <?php endif; ?>
</td>
<td width="10%">
<button type="button" class="btn btn-sm m-b-15 ml-2 mr-2 " onclick="confirmAlert('<?php echo e(Asset($link.'trash/'.$row->id)); ?>')">
<i class="mdi mdi-delete" style="font-size:22px;"></i>
</button>
</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>

</div>
</div>

<?php echo $data->links(); ?>


</div>
</div>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Cpanel_fda\fudi_app\local\resources\views/admin/dashboard/appUser.blade.php ENDPATH**/ ?>