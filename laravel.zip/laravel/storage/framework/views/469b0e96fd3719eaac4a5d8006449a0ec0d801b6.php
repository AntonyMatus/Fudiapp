<?php $__env->startSection('title'); ?> Push Notifications <?php $__env->stopSection(); ?>

<?php $__env->startSection('icon'); ?> mdi-send <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section class="pull-up">
<div class="container">
<div class="row ">
<div class="col-lg-10 mx-auto  mt-2">
<div class="card py-3 m-b-30">
<div class="card-body">
<?php echo Form::open(['url' => [$form_url],'files' => true],['class' => 'col s12']); ?>



<div class="form-row">
<div class="form-group col-md-12">
<label for="inputEmail6">Title</label>
<?php echo Form::text('title',null,['id' => 'code','class' => 'form-control','required' => 'required']); ?>

</div>
</div>

<div class="form-row">
    <div class="form-group col-md-6">
        <label for="inputEmail6">Selección de Ciudades</label>
        <select name="citys[]" class="form-control js-select2" multiple="true">
            <option value="all">Todas</option>
            <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id); ?>" <?php if(in_array($p->name,$array)): ?> selected <?php endif; ?>><?php echo e($p->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

</div>

<div class="form-row">
    <div class="form-group col-md-12">
        <label for="inputEmail6">Image (Recomended size 800 x 600)</label>
        <input type="file" name="img" class="form-control">
    </div>
</div>

<div class="form-row">
<div class="form-group col-md-12">
<label for="inputEmail6">Description (less then 250 words)</label>
<?php echo Form::textarea('desc',null,['id' => 'code','class' => 'form-control','required' => 'required','maxlength' => '250']); ?>

</div>
</div>

<button type="submit" class="btn btn-success btn-cta">Send</button>


</form>
</div>
</div>
</div>
</div>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/fudiapp.tumenu-digital.com.mx/public_html/laravel/resources/views/admin/push/index.blade.php ENDPATH**/ ?>