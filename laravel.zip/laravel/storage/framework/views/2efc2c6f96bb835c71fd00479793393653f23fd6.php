
<div class="form-row">
<input type="text" name="deliveryVia" value="admin" hidden>
<div class="form-group col-md-6">
<label for="inputEmail6">Nombre</label>
<?php echo Form::text('name',null,['id' => 'code','class' => 'form-control','required' => 'required']); ?>

</div>
<div class="form-group col-md-6">
<label for="inputEmail6">Ciudad</label>
<select name="city_id" class="form-control" required="required">
<option value="">Select City</option>
<?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($city->id); ?>" <?php if($data->city_id == $city->id): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>

<div class="form-row">
<div class="form-group col-md-6">
<label for="inputEmail6">Telefono (This will be username)</label>
<?php echo Form::text('phone',null,['id' => 'code','class' => 'form-control','required' => 'required']); ?>

</div>

<div class="form-group col-md-6">
<?php if($data->id): ?>
<label for="inputEmail6">Cambiar Contraeña</label>
<input type="password" name="password" class="form-control">
<?php else: ?>
<label for="inputEmail6">Contraseña</label>
<input type="password" name="password" class="form-control" required="required">
<?php endif; ?>
</div>
</div>

<div class="form-row">
	

	<div class="form-group col-md-6">
	<label for="inputEmail6">Estado</label>
	<select name="status" class="form-control">
		<option value="0" <?php if($data->status == 0): ?> selected <?php endif; ?>>Active</option>
		<option value="1" <?php if($data->status == 1): ?> selected <?php endif; ?>>Disbaled</option>
	</select>
	</div>
</div>


<button type="submit" class="btn btn-success btn-cta">Guardar Cambios</button>
<?php /**PATH C:\xampp\htdocs\Cpanel_fda\fudi_app\local\resources\views/admin/delivery/form.blade.php ENDPATH**/ ?>