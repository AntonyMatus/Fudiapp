<?php echo $__env->make('admin.order.dispatch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php if($row->status == 0): ?>

    <div class="btn-group" role="group">
    <button id="btnGroupDrop<?php echo e($row->id); ?>" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Opciones </button>

    <div class="dropdown-menu" aria-labelledby="btnGroupDrop<?php echo e($row->id); ?>" style="padding: 10px 10px">

    <a href="<?php echo e(Asset(env('admin').'/order/edit/'.$row->id)); ?>">Editar Pedido</a><hr>
    <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=1')); ?>" onclick="return confirm('Are you sure?')">Confirmar Pedido</a><hr>

    <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=2')); ?>" onclick="return confirm('Are you sure?')">Cancelar Pedido</a><hr>

    </div>
    </div>


<?php elseif($row->status == 1): ?>

    <?php if(!$row->dboy): ?>
    <div class="btn-group" role="group">
    <button id="btnGroupDrop<?php echo e($row->id); ?>" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Opciones </button>

    <div class="dropdown-menu" aria-labelledby="btnGroupDrop<?php echo e($row->id); ?>" style="padding: 10px 10px">

    <a href="<?php echo e(Asset(env('admin').'/order/edit/'.$row->id)); ?>">Editar Pedido</a><hr>

    <?php if($row->type == 2): ?>
    <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=7')); ?>" onclick="return confirm('Are you sure?')">Listo para entregar</a><hr>
    <?php elseif($row->type == 7): ?>
    <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=5')); ?>" onclick="return confirm('Are you sure?')">Entregar Pedido</a><hr>
    <?php else: ?>
    <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=1.5&staff_ext=1')); ?>" onclick="return confirm('Are you sure?')">Asignar Repartidor</a><hr>
    <?php endif; ?>

    <a href="<?php echo e(Asset(env('admin').'/order/print/'.$row->id)); ?>" target="_blank">Imprimir Recibo</a><hr>

    <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=2')); ?>" onclick="return confirm('Are you sure?')" style="color:red">Cancelar Pedido</a>

    </div>
    </div>
    <?php endif; ?>

    
<?php elseif($row->status == 1.5): ?>

<span style="font-size: 12px">Asignando Repartidor...</span><hr />
<div class="btn-group" role="group">
    <img src="https://i.pinimg.com/originals/2a/6b/65/2a6b651433f3c6ece42ba25439f76c0d.gif" alt="Buscando..." width="100%" style="border-radius:20px;">
</div>
<div>
</div>


<?php elseif($row->status == 2): ?>

    <span style="font-size: 12px">Cancelado a las <br><?php echo e($row->status_time); ?></span>

<?php elseif($row->status == 3): ?>

<span style="font-size: 12px">Repartidor en camino...</span><hr />
<div class="btn-group" role="group">
    <img src="https://media3.giphy.com/media/Pj19z6yzCpa1oQEvhe/giphy-downsized.gif" alt="en camino" width="50%">
</div>
<div>
</div>

<?php elseif($row->status == 3.5): ?>

<div class="btn-group" role="group">
    <button id="btnGroupDrop<?php echo e($row->id); ?>" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Opciones </button>
    <div class="dropdown-menu" aria-labelledby="btnGroupDrop<?php echo e($row->id); ?>" style="padding: 10px 10px">
        <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=3&staff_ext=1')); ?>" onclick="return confirm('Are you sure?')">Asignar Repartidor</a><hr>
        <a href="<?php echo e(Asset(env('admin').'/orderStatus?id='.$row->id.'&status=2')); ?>" onclick="return confirm('Are you sure?')">Cancelar Pedido</a>
        <a href="<?php echo e(Asset(env('admin').'/order/print/'.$row->id)); ?>" target="_blank">Imprimir factura</a>
    </div>
</div>
<hr>
<div >
<span style="font-size: 12px">Asignado a <?php echo e($row->dboy); ?> a las:<br><?php echo e($row->status_time); ?></span>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\FudiFoodActualizado\laravel\resources\views/admin/order/action.blade.php ENDPATH**/ ?>