<?php $__env->startSection('title'); ?> Administrar categorías <?php $__env->stopSection(); ?>

<?php $__env->startSection('icon'); ?> mdi-silverware-fork-knife <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section class="pull-up">
<div class="container">
<div class="row ">
<div class="col-md-12">
<div class="card py-3 m-b-30">

<div class="row">
    <div class="col-md-12" style="text-align: right;">
        <a href="<?php echo e(Asset($link.'add')); ?>" class="btn m-b-15 ml-2 mr-2 btn-rounded btn-warning">Add New</a>&nbsp;&nbsp;&nbsp;
    </div>
</div>


<div class="card-body">

<?php echo e(Form::open(['route' => 'search', 'method' =>'GET','class' => 'col s12'])); ?>

<div class="tab-content" id="myTabContent1">
	<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
       
        <div class="form-row">
            
        <div class="form-group col-md-3">
            <label for="inputEmail6">Nombre</label><br />
            <input type="text" name="name" id="name" value="<?php echo e($name); ?>" placeholder="Busca por nombre" class="form-control" autocomplete="off">
        </div>
        
        <div class="form-group col-md-3">
            <label for="inputEmail6">Tipo Menu</label>
            <select name="type" class="form-control" id="type">
                <option value="0" <?php if($type == 0): ?> selected <?php endif; ?>>De Menú</option>
                <option value="1" <?php if($type == 1): ?> selected <?php endif; ?>>De Complementos</option>
            </select>
        </div>     
        <div class="form-group col-md-1">
            <button type="submit" class="btn btn-success m-b-15 ml-2 mr-2" style="margin-top:30px;">Buscar</button>
        </div>
        
        <div class="form-group col-md-2">
            <a href="<?php echo e(Asset($link)); ?>" class="btn btn-success m-b-15 ml-2 mr-2" style="margin-top:30px;">Ver todo</a>
        </div>
               
        </div>
       
    </div>
</div>
<?php echo e(Form::close()); ?>


<table class="table table-hover ">
<thead>
<tr>
<th>Sort Order</th>
<th>Name</th>
<th>Tipo</th>
<th>Status</th>
<th style="text-align: right">Option</th>
</tr>

</thead>
<tbody>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td width="15%"><?php echo e($row->sort_no); ?></td>
<td width="20%"><?php echo e($row->name); ?> 
    <?php if($row->id_element != ''): ?>
    <small>(<?php echo e($row->id_element); ?>)</small>
    <?php endif; ?>
</td>
<td width="20%">
    <?php if($row->type == 0): ?>
        De Menú
    <?php else: ?>
        De Complemento
    <?php endif; ?>
</td>
<td width="27%">
<?php if($row->status == 0): ?>

<button type="button" class="btn btn-sm m-b-15 ml-2 mr-2 btn-success" onclick="confirmAlert('<?php echo e(Asset($link.'status/'.$row->id)); ?>')">Active</button>

<?php else: ?>

<button type="button" class="btn btn-sm m-b-15 ml-2 mr-2 btn-danger" onclick="confirmAlert('<?php echo e(Asset($link.'status/'.$row->id)); ?>')">Disabled</button>

<?php endif; ?>

</td>

<td width="19%" style="text-align: right">

<a href="<?php echo e(Asset($link.$row->id.'/edit')); ?>" class="btn m-b-15 ml-2 mr-2 btn-md  btn-rounded-circle btn-success" data-toggle="tooltip" data-placement="top" data-original-title="Edit This Entry"><i class="mdi mdi-border-color"></i></a>

<button type="button" class="btn m-b-15 ml-2 mr-2 btn-md  btn-rounded-circle btn-danger" data-toggle="tooltip" data-placement="top" data-original-title="Delete This Entry" onclick="deleteConfirm('<?php echo e(Asset($link."delete/".$row->id)); ?>')"><i class="mdi mdi-delete-forever"></i></button>


</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>
<?php echo $data->links(); ?>

</div>
</div>
</div>
</div>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/customer/www/fudiapp.tumenu-digital.com.mx/public_html/laravel/resources/views/user/category/index.blade.php ENDPATH**/ ?>