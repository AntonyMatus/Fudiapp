<div class="row">
<div class="col-lg-12 m-b-30">
<div class="card">
<div class="card-header">
<div class="card-title">Pedidos Recientes</div>

<div class="card-controls">

<a href="#" class="js-card-refresh icon"> </a>

</div>

</div>

<div class="table-responsive">

<table class="table table-hover table-sm ">
<thead>
<tr>
<th>Order ID</th>
<th>Type</th>
<th>User</th>
<th>Address</th>
<th>Status</th>
<th>Order Time</th>
<th class="text-center">Action</th>
</tr>
</thead>
<tbody>
<tr>

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
<td width="10%">#<?php echo e($row->id); ?></td>
<td width="20%">
<br>
<?php if($row->type == 1): ?>

<small style="color:blue">Entrega a domcilio</small>

<?php else: ?>

<small style="color:green">Recogido</small>


<?php endif; ?>
<td width="15%"><?php echo e($row->name); ?><br><?php echo e($row->phone); ?></td>
<td width="15%"><?php echo e($row->address); ?></td>
<td width="15%"><?php echo $row->getStatus($row->id); ?></td>
<td width="15%"><?php echo e(date('d-M-Y',strtotime($row->created_at))); ?></td>
<td width="15%"><?php echo $__env->make('admin.order.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tr>

</tbody>
</table>

</div>
<?php echo $orders->links(); ?>

</div>
</div>
</div><?php /**PATH C:\xampp\htdocs\Cpanel_fda\yomiyomi\local\resources\views/admin/dashboard/order.blade.php ENDPATH**/ ?>