<a href="#" class="sidebar-toggle" data-toggleclass="sidebar-open" data-target="body"> </a>
<nav class=" mr-auto my-auto">
    <ul class="nav align-items-center">
        <li class="nav-item" style="margin-left: 35px;padding-top:12px;"> 
        <h4 style="color:#fff;">Restaurant Manager</h4>
        </li>
    </ul>
</nav>
<nav class=" ml-auto">
    <ul class="nav align-items-center">
        <li style="font-size: 18px">
            <a class="dropdown-item" style="color:#fff;float:right;" href="<?php echo e(Asset(env('admin').'/logout')); ?>">  Logout </a>
        </li>
    </ul>
</nav><?php /**PATH C:\xampp\htdocs\Cpanel_fda\fudi_app\local\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>