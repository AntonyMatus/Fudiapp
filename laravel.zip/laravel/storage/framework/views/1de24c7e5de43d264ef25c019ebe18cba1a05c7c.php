<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<table>
  <thead>
    <tr>
      <td><b>ID</b></td>
      <td><b>Fecha</b></td>
      <td><b>Ciudad</b></td>
      <td><b>Usuario</b></td>
      <td><b>Email</b></td>
      <td><b>Telefono</b></td>
      <td><b>Comercio</b></td>
      <td><b>Entrega</b></td>
      <td><b>Dirección</b></td>
      <td><b>Status</b></td>
      <td><b>Tipo de envio</b></td>
      <td><b>Repartidor</b></td>
      <td><b>C/Productos</b></td>
      <td><b>Comisión del restaurante</b></td>
      <td><b>Monto de comision</b></td>
      <td><b>Valor del Cupon</b></td>
      <td><b>Costo con Cupon aplicado</b></td>
      <td><b>Costo de envio</b></td>
      <td><b>Comision de envio</b></td>
      <td><b>Cantidad de comision de envio</b></td>
      <td><b>Monto total</b></td>
      <td><b>Tipo de pago</b></td>
      <td><b>Status del pago</b></td>
    </tr>
  </thead>
  <tbody>
    <?php ($total = []); ?>
    <?php ($com = []); ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php ($com[] = $user->getCom($row['id'],$row['amount'])); ?>

    <tr>
      <td>#<?php echo e($row['id']); ?></td>
      <td><?php echo e($row['date']); ?></td>
      <td><?php echo e($row['city']); ?></td>
      <td><?php echo e($row['user']); ?></td>
      <td><?php echo e($row['email']); ?></td>
      <td><?php echo e($row['phone']); ?></td>
      <td><?php echo e($row['store']); ?></td>
      <td><?php echo e($row['type']); ?></td>
      <td><?php echo e($row['addr']); ?></td>
      <td><?php echo e($row['status']); ?></td>
      <td><?php echo e($row['type_staff']); ?></td>
      <td><?php echo e($row['name_staff']); ?></td>
      <td><?php echo e($row['tot_prods']); ?></td>
      <td><?php echo e($row['commision']); ?></td>
      <td>$<?php echo e($row['comm_amount']); ?></td>
      <td>$<?php echo e($row['cupon_value']); ?></td>
      <td>$<?php echo e($row['cupon_amount']); ?></td>
      <td>$<?php echo e($row['amount_send']); ?></td>
      <td><?php echo e($row['costs_ship']); ?></td>
      <td>$<?php echo e($row['amount_ship']); ?></td>
      <td>$<?php echo e($row['amount']); ?></td>
      <td><?php echo e($row['payment']); ?></td>
      <td><?php echo e($row['pay_status']); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
  </tbody>
</table>


<table>
  <thead>
    <tr>
      <td><b>Cantidad de Productos</b></td>
    </tr>
  </thead>
</table>


<table>
  <thead>
    <tr>
      <td><b>ID Pedido</b></td>
      <td><b>N/ Producto</b></td>
      <td><b>C/ Producto</b></td>
      <td><b>$/ Producto</b></td>
    </tr>
  </thead>
  <tbody>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $row['productos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php ($total[] = $productos->price); ?>
<tr>
  <td>#<?php echo e($row['id']); ?></td>
  <td><?php echo e($productos->name); ?></td>
  <td><?php echo e($productos->qty); ?></td>
  <td>$<?php echo e($productos->price); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

    <tr>
      <td>&nbsp;</td>
      <td >&nbsp;<b>Montos</b></td>
      <td >&nbsp;<b><?php echo e(count($total)); ?></b></td>
      <td >&nbsp;<b>$<?php echo e(array_sum($total)); ?></b></td>
      <td >&nbsp;<b><?php echo e(array_sum($com)); ?></b></td>
    </tr>
</tbody>
</table>
 
</body>
</html><?php /**PATH C:\xampp\htdocs\Cpanel_fda\yomiyomi\local\resources\views/admin/report/report.blade.php ENDPATH**/ ?>