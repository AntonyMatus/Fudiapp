<?php $admin = app('App\Admin'); ?>


<?php ($page = Request::segment(2)); ?>
<style type="text/css">
.menu-item{
	border-bottom: 1px solid #0c6057 !important;
}
</style>
<div class="admin-sidebar-brand">
<!-- begin sidebar branding-->
<img class="admin-brand-logo" src="<?php echo e(Asset('assets/img/logo.png')); ?>" width="40" alt="atmos Logo">
<span class="admin-brand-content font-secondary"><a href="<?php echo e(Asset(env('admin').'/home')); ?>">  Admin</a></span>
<!-- end sidebar branding-->
<div class="ml-auto">
<!-- sidebar pin-->
<a href="#" class="admin-pin-sidebar btn-ghost btn btn-rounded-circle"></a>
<!-- sidebar close for mobile device-->
<a href="#" class="admin-close-sidebar"></a>
</div>
</div>
<div class="admin-sidebar-wrapper js-scrollbar">
<ul class="menu">
<li class="menu-item <?php if($page === 'home' || $page == 'setting'): ?> active <?php endif; ?>">
<a href="#" class="open-dropdown menu-link">
<span class="menu-label">
<span class="menu-name">Dashboard
<span class="menu-arrow"></span>
</span>

</span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-shape-outline "></i>
</span>
</a>
<!--submenu-->
<ul class="sub-menu">

<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/home')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Home</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-home">

</i>
</span>
</a>
</li>
<?php if($admin->hasPerm('setting')): ?>
<li class="menu-item ">
<a href="<?php echo e(Asset(env('admin').'/setting')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Settings</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-message-settings-variant">

</i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage Sub Account')): ?>
<li class="menu-item ">
<a href="<?php echo e(Asset(env('admin').'/adminUser')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Sub Accounts</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-account">

</i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage App Text')): ?>

<li class="menu-item ">
<a href="<?php echo e(Asset(env('admin').'/text/add')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">App Text</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-message-settings-variant">

</i>
</span>
</a>
</li>
<?php endif; ?>
</ul>
</li>

<?php if($admin->hasPerm('Manage Language')): ?>
<li class="menu-item <?php if($page === 'language'): ?> active <?php endif; ?>">
<a href="<?php echo e(Asset(env('admin').'/language')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Languages</span></span>
<span class="menu-icon">
 <i class="mdi mdi-calendar-edit"></i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage Banners')): ?>
<li class="menu-item <?php if($page === 'slider' || $page == 'banner'): ?> active <?php endif; ?>">
<a href="#" class="open-dropdown menu-link">
<span class="menu-label">
<span class="menu-name">Banners
<span class="menu-arrow"></span>
</span>

</span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-image-filter "></i>
</span>
</a>
<!--submenu-->
<ul class="sub-menu">
<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/slider')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Welcome Slider</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-image-filter">

</i>
</span>
</a>
</li>

<li class="menu-item ">
<a href="<?php echo e(Asset(env('admin').'/banner')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Banners</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-image">

</i>
</span>
</a>
</li>
</ul>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage City')): ?>
<li class="menu-item <?php if($page === 'city'): ?> active <?php endif; ?>">
<a href="<?php echo e(Asset(env('admin').'/adminUser')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Manage Cities</span></span>
<span class="menu-icon">
 <i class="mdi mdi-map-marker"></i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage App Pages')): ?>
<li class="menu-item <?php if($page === 'page'): ?> active <?php endif; ?>">
<a href="<?php echo e(Asset(env('admin').'/page/add')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">App Pages</span></span>
<span class="menu-icon">
 <i class="mdi mdi-file"></i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage Stores')): ?>
<li class="menu-item <?php if($page === 'user'): ?> active <?php endif; ?>">
<a href="<?php echo e(Asset(env('admin').'/user')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Manage Restaurants</span></span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-home"></i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage Discount Offer')): ?>
<li class="menu-item <?php if($page === 'offer'): ?> active <?php endif; ?>">
<a href="<?php echo e(Asset(env('admin').'/offer')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Discount Offers</span></span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-calendar"></i>
</span>
</a>
</li>
<?php endif; ?>


<?php if($admin->hasPerm('Manage Staff Member')): ?>
<li class="menu-item <?php if($page === 'delivery'): ?> active <?php endif; ?>">
<a href="<?php echo e(Asset(env('admin').'/delivery')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Staff Members</span></span>
<span class="menu-icon">
<i class="mdi mdi-account-clock"></i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage Orders')): ?>
<li class="menu-item <?php if($page === 'order'): ?> active <?php endif; ?>">
<a href="#" class="open-dropdown menu-link">
<span class="menu-label">
<span class="menu-name">Manage Orders 

<?php
$cOrder = DB::table('orders')->where('status',0)->count();
$rOrder = DB::table('orders')->where('status',1)->count();
if($cOrder > 0)
{
?>

<span class="icon-badge badge-success badge badge-pill"><?php echo e($cOrder); ?></span>

<?php } ?>

<span class="menu-arrow"></span>
</span>

</span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-cart"></i>
</span>
</a>
<!--submenu-->
<ul class="sub-menu">

<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/order?status=0')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">New Orders

<?php if($cOrder > 0): ?>

<span class="icon-badge badge-success badge badge-pill"><?php echo e($cOrder); ?></span>

<?php endif; ?>

</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-cart">

</i>
</span>
</a>
</li>


<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/order?status=1')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Running Orders

<?php if($rOrder > 0): ?>

<span class="icon-badge badge-success badge badge-pill"><?php echo e($rOrder); ?></span>

<?php endif; ?>

</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-camera-control">

</i>
</span>
</a>
</li>

<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/order?status=2')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Cancelled Orders</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-cancel">

</i>
</span>
</a>
</li>

<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/order?status=4')); ?>" class=" menu-link">
<span class="menu-label">
<span class="menu-name">Completed Orders</span>
</span>
<span class="menu-icon">
<i class="icon-placeholder  mdi mdi-check-all">

</i>
</span>
</a>
</li>
</ul>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage Push Notification')): ?>
<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/push')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Push Notification</span></span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-send"></i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage Reporting')): ?>
<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/report')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Reporting</span></span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-file"></i>
</span>
</a>
</li>
<?php endif; ?>

<?php if($admin->hasPerm('Manage App User')): ?>
<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/appUser')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">App Users</span></span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-account"></i>
</span>
</a>
</li>
<?php endif; ?>


<?php if($admin->hasPerm('Manage Payment')): ?>
<li class="menu-item <?php if($page === 'payment'): ?> active <?php endif; ?>">
<a href="<?php echo e(Asset(env('admin').'/payment')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Order Payment</span></span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-calendar"></i>
</span>
</a>
</li>
<?php endif; ?>

<li class="menu-item">
<a href="<?php echo e(Asset(env('admin').'/logout')); ?>" class="menu-link">
<span class="menu-label"><span class="menu-name">Logout</span></span>
<span class="menu-icon">
<i class="icon-placeholder mdi mdi-logout"></i>
</span>
</a>
</li>

</ul>
</div>
<?php /* /Applications/XAMPP/xamppfiles/htdocs/fda_ibh/local/resources/views/admin/layout/menu.blade.php */ ?>