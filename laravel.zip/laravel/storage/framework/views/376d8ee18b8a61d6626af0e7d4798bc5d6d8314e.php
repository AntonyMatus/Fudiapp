<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<table>
  <thead>
    <tr>
      <td><b>#</b></td>
      <td><b>ID</b></td>
      <td><b>Repartidor</b></td>
      <td><b>Email</b></td>
      <td><b>Comercio</b></td>
      <td><b>% Plataforma</b></td>
      <td><b>Tipo de Comisión</b></td>
      <td><b>% Repartidor</b></td>
      <td><b>Total</b></td>
    </tr>
  </thead>
  
  <tbody>
    <?php ($total = []); ?>
    <?php ($id = 0); ?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($total[] = $row['total']); ?>
            <tr>
                <td><?php echo e(count($total)); ?></td>
                <td><?php echo e($row['id']); ?></td>
                <td><?php echo e($row['name']); ?> &nbsp;(<small><?php echo e($row['rfc']); ?></small>)</td>
                <td><?php echo e($row['email']); ?></td>
                <td><?php echo e($row['store']); ?> &nbsp;(<small><?php echo e($row['store_rfc']); ?></small>)</td>
                <td><?php echo e($row['platform_porcent']); ?></td>
                <td><?php echo e($row['type_staff_porcent']); ?></td>
                <td><?php echo e($row['staff_porcent']); ?></td>
                <td><?php echo e($row['total']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table> 
</body>
</html><?php /**PATH C:\xampp\htdocs\FudiFoodActualizado\laravel\resources\views/admin/report/report_staff.blade.php ENDPATH**/ ?>