<div class="tab-content" id="myTabContent1">
<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">


<div class="form-row">
	<div class="form-group col-md-6">
		<label for="inputEmail6">selecciona una categoría <small>(Debes Agregarlas en area de categorias)</small></label>
		<select name="cate_id" class="form-control" required="required">
		<option value="">Select</option>

		<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php if($data->category_id == $cat->id): ?> selected <?php endif; ?>><?php echo e($cat->name); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>

	<div class="form-group col-md-6">
		<label for="inputEmail6">Nombre</label>
		<?php echo Form::text('name',null,['id' => 'code','placeholder' => 'Name','class' => 'form-control']); ?>

	</div>
</div>

<div class="form-row">
	<div class="form-group col-md-6">
		<label for="inputEmail6">Descripción</label>
		<?php echo Form::text('description',null,['id' => 'code','placeholder' => 'Item Description','class' => 'form-control']); ?>

	</div>

	<div class="form-group col-md-6">
		<label for="inputEmail6">Estado</label>
		<select name="status" class="form-control">
			<option value="0" <?php if($data->status == 0): ?> selected <?php endif; ?>>Active</option>
			<option value="1" <?php if($data->status == 1): ?> selected <?php endif; ?>>Disbaled</option>
		</select>
	</div>

	<div class="form-group col-md-6">
		<label for="inputEmail6">Imagen</label>
		<input type="file" name="img" class="form-control">
	</div>

	<div class="form-row">
		<div class="form-group col-md-6">
			<label for="inputEmail6">Orden de clasificación</label>
			<?php echo Form::number('sort_no',null,['id' => 'code','class' => 'form-control']); ?>

		</div>

		<div class="form-group col-md-6">
			<label for="inputEmail6">Cantidad</label>
			<?php echo Form::number('qty',null,['id' => 'code','class' => 'form-control']); ?>

		</div>
	</div>
</div>

<div class="form-row">

	<div class="form-group col-md-4">
		<label for="inputEmail6"><?php echo e($text['item_small']); ?></label>
		<?php echo Form::number('small_price',null,['id' => 'code','class' => 'form-control', 'pattern' =>'[0-9]', 'required' => 'required']); ?>

	</div>

	<div class="form-group col-md-4">
		<label for="inputEmail6"><?php echo e($text['item_m']); ?></label>
		<?php echo Form::number('medium_price',null,['id' => 'code','class' => 'form-control']); ?>

	</div>

	<div class="form-group col-md-4">
		<label for="inputEmail6"><?php echo e($text['item_large']); ?></label>
		<?php echo Form::number('large_price',null,['id' => 'code','class' => 'form-control']); ?>

	</div>
</div>

<div class="form-row">
	<div class="form-group col-md-12">
		<label for="inputEmail6">Agregar Conjunto de Modificadores</label>

		
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<input type="hidden" name="item_id" value="<?php echo e($data->id); ?>">


		<select name="a_id[]" class="form-control js-select2" multiple="true">
		<?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($cate->type == 1): ?>
			<option value="<?php echo e($cate->id); ?>" <?php if(in_array($cate->id,$arrayCate)): ?> selected <?php endif; ?>>
				<?php echo e($cate->name); ?> 
				<?php if($cate->id_element != ''): ?>
					<small>(<?php echo e($cate->id_element); ?>)</small>
				<?php endif; ?>
			</option>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
</div>

</div>
<button type="submit" class="btn btn-success btn-cta">Guardar Cambios</button>

<?php $__env->startSection('js'); ?>
<script>
var input = document.getElementById('code');

input.oninvalid = function(event) {
    event.target.setCustomValidity('Por favor escriba solo numeros en este Campo!');
}
</script>

<?php $__env->stopSection(); ?>
<?php /**PATH /home/u506348621/domains/fudifood.com.mx/public_html/dash/laravel/resources/views/user/item/form.blade.php ENDPATH**/ ?>