<?php $__env->startSection('title'); ?> Amortización <?php $__env->stopSection(); ?>

<?php $__env->startSection('icon'); ?> mdi-calendar <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<section class="pull-up">
<div class="container">
<div class="row ">
<div class="col-lg-10 mx-auto  mt-2">
<div class="card py-3 m-b-30">
<div class="card-body">
<?php echo Form::model($data, ['url' => [$form_url],'files' => true,'method' => 'PATCH'],['class' => 'col s12']); ?>


<div class="form-row">
    <input type="text" name="deliveryVia" value="admin" hidden>
    <div class="form-group col-md-6">
    <label for="inputEmail6">Debe al Admin</label>
    <?php echo Form::number('Debe_Admin',null,['id' => 'code','class' => 'form-control','required' => 'required']); ?>

    </div>
    <div class="form-group col-md-6">
        <label for="inputEmail6">Pagar al Admin</label>
        <?php echo Form::number('Pagar_Admin',null,['id' => 'code','class' => 'form-control','required' => 'required']); ?>

    </div>
</div>
<button type="submit" class="btn btn-success btn-cta">Guardar Cambios</button>
</form>
</div>
</div>
</div>
</div>
</div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FudiFoodActualizado\laravel\resources\views/admin/delivery/pay.blade.php ENDPATH**/ ?>