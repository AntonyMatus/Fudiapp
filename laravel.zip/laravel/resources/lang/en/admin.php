<?php

return [

'title' 		=> 'Bienvenido(a) al panel de administración',
'userTitle' 	=> 'Inicie sesión para continuar',

];