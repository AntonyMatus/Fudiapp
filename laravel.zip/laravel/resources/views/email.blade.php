<h2>Dear {{ $res->name }},</h2>

<p>{{ $res->otp }} is OTP for reset your password.</p>
